import AWS from "aws-sdk";

// Cấu hình AWS SDK
AWS.config.update({
    accessKeyId: "AKIAWC7EA5QLPPF6ZVG7",
    secretAccessKey: "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",
    region: "ap-southeast-1",
});

// Hàm gửi email
export const sendEmailSmtp = (recipient, subject, htmlContent) => {
    const ses = new AWS.SES({ apiVersion: "2010-12-01" });

    const params = {
        Destination: {
            ToAddresses: [recipient],
        },
        Message: {
            Body: {
                Html: { Data: htmlContent },
            },
            Subject: { Data: subject },
        },
        Source: "maithanhbinh13102003@gmail.com",
    };

    return new Promise((resolve, reject) => {
        ses.sendEmail(params, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
};
