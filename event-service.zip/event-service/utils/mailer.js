import nodeMailer from "nodemailer";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
import { fileURLToPath } from "url";

import fs from "fs";
import path from "path";

// Đọc nội dung của file HTML
// const emailTemplatePath = path.join(__dirname, "index.html");
// const emailTemplate = fs.readFileSync(emailTemplatePath, "utf8");

export const sendMail = async (to, subject, text, imageUrl) => {
    return new Promise((resolve, reject) => {
        const transport = nodeMailer.createTransport({
            host: "smtp.gmail.com",
            port: 587,
            secure: false,
            auth: {
                user: "maithanhbinh13102003@gmail.com",
                pass: "pade meun ipee tnwh",
            },
        });

        const mailOptions = {
            from: "maithanhbinh13102003@gmail.com",
            to: to,
            subject: subject,
            html: `
                <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd;">
                    <h1 style="color: #333; margin-bottom: 20px;">${subject}</h1>
                    <p style="font-size: 16px; color: #666; margin-bottom: 20px;">${text}</p>
                    <img src="${imageUrl}" alt="Image Event" style="max-width: 100%; height: auto; display: block; margin-bottom: 20px;">
                    <p style="font-size: 14px; color: #888;">This email was sent by ThanhBinh.</p>
                </div>
            `,
            // html: emailTemplate,
        };

        transport.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log(error);
                reject({
                    status: "error",
                    message: "Cannot send email",
                });
            } else {
                resolve({
                    status: "success",
                    message: "Email sent: " + info.response,
                });
            }
        });
    });
};
