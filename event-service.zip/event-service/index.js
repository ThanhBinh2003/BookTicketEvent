import mongoose from "mongoose";
import express from "express";
import flash from "express-flash";
import session from "express-session";
import cookieParser from "cookie-parser";
import path from "path";
import expressEjsLayouts from "express-ejs-layouts";
import cors from "cors";
import { dirname } from "path";
import { fileURLToPath } from "url";
import accountRoutes from "./routers/account.js";
import authRoutes from "./routers/auth.js";
import eventRoutes from "./routers/event.js";
import orderRoutes from "./routers/order.js";
import organizationRoutes from "./routers/organiztion.js";
import surveyRoutes from "./routers/survey.js";
import { checkToken, checkRole, getUser } from "./middlewares/auth.js";

import dotenv from "dotenv";

//configuration

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config();
const app = express();
// app.use(cors());
app.use(expressEjsLayouts);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/", express.static(path.join(__dirname, "public")));
app.use(cookieParser());
app.use(
    session({
        secret: process.env.SECRET,
        resave: false,
        saveUninitialized: true,
        // cookie: { secure: true }
    })
);

app.use(flash());

app.set("view engine", "ejs");

// Kết nối đến cơ sở dữ liệu MongoDB
const uri = process.env.MONGODB_URI;

mongoose
    .connect(uri, {})
    .then(() => {
        console.log("Kết nối cơ sở dữ liệu account thành công:\n", uri);
    })
    .catch((error) => {
        console.error("Lỗi kết nối cơ sở dữ liệu account:", error);
    });

//use router
app.use(getUser);
app.use("/auth", authRoutes);
app.use("/account", checkToken, accountRoutes);
app.use("/order", checkToken, orderRoutes);
app.use("/organization", checkToken, organizationRoutes);
app.use("/survey", checkToken, surveyRoutes);
app.use("/", checkToken, eventRoutes);

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`http://localhost:${port}`));
