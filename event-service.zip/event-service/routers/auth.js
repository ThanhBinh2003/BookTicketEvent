import express from "express";
import {
    changePassword,
    getLogin,
    getRegiter,
    logout,
    postLogin,
    postRegister,
} from "../controller/authController.js";

const router = express.Router();

// [post] /auth/register
router.post("/register", postRegister);

// [get] /auth/login
router.get("/login", getLogin);

// [post] /auth/login
router.post("/login", postLogin);

// [get] auth/logout
router.get("/logout", logout);

//[get] /auth/register
router.get("/register", getRegiter);

//[post] /auth/changePassword
router.post("/changePassword", changePassword);

export default router;
