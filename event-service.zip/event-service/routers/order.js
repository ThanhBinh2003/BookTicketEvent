import express from "express";
import {
    VNPay,
    VNPayReturn,
    getBooking,
    getOrder,
    getOrderPage,
    getStatisticsPage,
    payZalo,
    store,
} from "../controller/orderController.js";

const router = express.Router();

//get Page
router.get("/checkout", getOrderPage);

//[post]
router.post("/store", store);
//[get] get data
router.get("/getdata", getOrder);
//[get] page booing
router.get("/booking", getBooking);

router.post("/create_payment_url", VNPay);

router.get("/vnpay_return", VNPayReturn);

router.post("/create_zalopayment_url", payZalo);

router.get("/statistics", getStatisticsPage);

export default router;
