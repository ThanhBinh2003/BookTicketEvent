import express from "express";
import {
    getQuestionPage,
    getSurveyPage,
    getUserSurveyPage,
} from "../controller/surveyController.js";

const router = express.Router();

// admin
router.get("/", getSurveyPage);

// user
router.get("/userSurvey", getUserSurveyPage);

router.get("/question", getQuestionPage);

export default router;
