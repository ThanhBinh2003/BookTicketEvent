import express from "express";
const router = express.Router();
import {
    deleteUser,
    editUser,
    getAccount,
    getProfilePage,
    index,
} from "../controller/accountController.js";
import { checkRole } from "../middlewares/auth.js";

//[get] /
router.get("/", checkRole(["admin"]), index);

//[get]/account/getAccount
router.get("/getAccount", checkRole(["admin"]), getAccount);

//[delete] /uid
router.delete("/delete/:uid", checkRole(["admin"]), deleteUser);

//[put] /edit/uid
router.put("/edit/:uid", checkRole(["admin"]), editUser);

//[get] /profie
router.get("/profile", getProfilePage);

export default router;
