import express from "express";
import {
    delOr,
    editOr,
    getOr,
    getOrPage,
    postOr,
} from "../controller/organiztionController.js";

const router = express.Router();

//[post] /add
router.post("/add", postOr);

//[get] /getOr
router.get("/getOr", getOr);

//[get] /organization
router.get("/", getOrPage);

//[put] /edit
router.put("/edit/:oid", editOr);

//[delete] /delete
router.delete("/delete/:oid", delOr);

export default router;
