import express from "express";
import {
    deleteEvetn,
    detailEvent,
    editEvent,
    getCancelPage,
    getDetailPaidEvent,
    getFeeEvent,
    getFeeEventPage,
    getFeeEventUserPage,
    getManageEvent,
    getManageEventById,
    getSuccessPage,
    listEvent,
    listUserEvent,
    listUserRegister,
    postEvent,
    renderEventPage,
    sendMailEvent,
} from "../controller/eventController.js";

import { checkRole } from "../middlewares/auth.js";

const router = express.Router();

// [get --role: admin] events/
router.get("/getEvent", getManageEvent);

//[get] --role: admin
router.get("/getEventById/:eid", getManageEventById);

//[get] getFeeEvent
router.get("/getFeeEvent", getFeeEvent);

//render event page
router.get("/", checkRole(["admin"]), renderEventPage);

//[post] events/add
router.post("/add", postEvent);

//[delete] events/delete/eId
router.delete("/delete/:eId", deleteEvetn);

//[put] events/edit/eId
router.put("/edit/:eId", editEvent);

//[get --role: user] events/
router.get("/userEvent", listEvent);

//[get] --role user
router.get("/userFee", getFeeEventUserPage);

//[post] events/sendEventEmail
router.post("/sendEventMail", sendMailEvent);

//[get] events/listRegister
router.get("/listUser/:eid", listUserRegister);

//[get] events/userEvents
router.get("/listEvents/:uid", listUserEvent);

//[get] events/detailEvent
router.get("/detail/:eid", detailEvent);

//[get] /feeEvent
router.get("/feeEvent", getFeeEventPage);

//[get] //detail
router.get("/detailFee/:eid", getDetailPaidEvent);

//get success
router.get("/success", getSuccessPage);
router.get("/cancel", getCancelPage);
export default router;
