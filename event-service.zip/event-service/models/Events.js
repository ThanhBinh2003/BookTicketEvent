import mongoose from "mongoose";

const durationSchema = mongoose.Schema({
    startTime: {
        type: String,
        require: [true, "Please add start time"],
    },
    endTime: {
        type: String,
        require: [true, "Please add end time"],
    },
});

const eventSchema = mongoose.Schema({
    picture: {
        type: String,
    },
    eventName: {
        type: String,
        require: [true, "Please add envent name"],
    },
    address: {
        type: String,
        require: [true, "Please add address"],
    },
    isFree: {
        type: Boolean,
        reqwuire: true,
    },
    ticketPrice: {
        type: Number,
        require: true,
    },
    quantity: {
        type: Number,
    },
    category: {
        type: String,
        enum: ["drama", "music", "orthers"],
    },
    organization: {
        type: Object,
    },
    startDate: {
        type: String,
        require: [true, "Please add start time"],
    },
    endDate: {
        type: String,
        require: [true, "Please add end time"],
    },
    duration: {
        type: durationSchema,
        require: true,
    },
    users: {
        type: [
            {
                userId: {
                    type: Object,
                },
                email: {
                    type: String,
                },
                registerTime: {
                    type: String,
                },
            },
        ],
    },
    state: {
        type: Boolean,
        require: [true, "Please enter your state"],
        default: true,
    },
    contentEvent: {
        type: String,
    },
});

const Event = mongoose.model("Event", eventSchema);

export default Event;
