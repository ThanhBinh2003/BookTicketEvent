import mongoose from "mongoose";

const questionSchema = mongoose.Schema({
    surveyId: {
        type: Object,
        require: true,
    },
    userId: {
        type: Object,
        require: true,
    },
    isMandatory: {
        type: Boolean,
        require: true,
    },
});

const question = mongoose.model("question", questionSchema);

export default question;
