import mongoose from "mongoose";

const organizationSchema = mongoose.Schema({
    name: {
        type: String,
        require: true,
    },
    about: {
        type: String,
        default: "Update ...",
    },
    address: {
        type: String,
        require: true,
    },
    email: {
        type: String,
        require: true,
    },
    phone: {
        type: Number,
        require: true,
    },
});

const organization = mongoose.model("organization", organizationSchema);

export default organization;
