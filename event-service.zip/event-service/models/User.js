// models/user.js
import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        require: true,
    },
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
    },
    password: {
        type: String,
    },
    role: {
        type: String,
        required: true,
        enum: ["admin", "user"],
    },
    phone: {
        type: String,
        default: "",
    },
    gender: {
        type: String,
        require: true,
    },
    createdAt: {
        type: String,
        required: true,
    },
});

const User = mongoose.model("User", userSchema);
import bcrypt from "bcrypt";
import moment from "moment";
try {
    // Tạo tài khoản admin/admin
    User.findOne({ email: "admin@gmail.com" }).then(async (user) => {
        if (!user) {
            const hashedPassword = await bcrypt.hash("admin", 10);
            User.create({
                username: "admin",
                name: "Admin",
                email: "admin@gmail.com",
                password: hashedPassword,
                role: "admin",
                phone: "",
                gender: "male",
                createdAt: moment().format("MM/DD/YYYY, hh:mm:ss"),
            }).then((user) => {
                console.log("Tạo tài khoản admin thành công");
            });
        } else {
            console.log("Tài khoản admin đã tồn tại");
        }
    });
} catch (error) {
    console.log(error);
}

export default User;
