import mongoose from "mongoose";

const surveySchema = mongoose.Schema({
    name: {
        type: String,
        require: true,
    },
    state: {
        type: Boolean,
        default: true,
    },
    startTime: {
        type: String,
        require: [true, "Please add start time"],
    },
    endTime: {
        type: String,
        require: [true, "Please add end time"],
    },
    minResponses: {
        type: Number,
    },
    maxResponses: {
        type: Number,
    },
});

const Survey = mongoose.model("survey", surveySchema);

export default Survey;
