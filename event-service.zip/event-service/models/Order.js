import mongoose from "mongoose";

const orderSchema = mongoose.Schema(
    {
        userId: {
            type: String,
            require: true,
        },
        items: {
            type: {
                eventId: {
                    type: Object,
                    require: true,
                },
                quantity: {
                    type: Number,
                    require: true,
                },
            },
            require: true,
        },
        isPay: {
            type: Boolean,
            require: true,
        },
        totalPice: {
            type: Number,
            require: true,
        },
        paymentMethod: {
            type: String,
        },
        createdAt: {
            type: String,
            require: true,
        },
        timestamp: {
            type: Number,
            require: true,
        },
    },
    {
        toObject: { virtuals: true },
        toJSON: { virtuals: true },
    }
);

orderSchema.virtual("user", {
    ref: "User",
    localField: "userId",
    foreignField: "username",
    justOne: true,
});

orderSchema.virtual("events", {
    ref: "Events",
    localField: "item.eventId",
    foreignField: "_id",
    justOne: true,
});
const Order = mongoose.model("Order", orderSchema);

export default Order;
