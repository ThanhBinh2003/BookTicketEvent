import organization from "../models/organization.js";
import Pakage from "../middlewares/pakage.js";
import e from "express";

export const postOr = async (req, res) => {
    try {
        const { name, about, address, email, phone } = req.body;

        const data = new organization({
            name: name,
            about: about,
            address: address,
            email: email,
            phone: phone,
        });

        const result = await data.save();
        if (!result)
            return res
                .status(400)
                .json(Pakage(1, "Can not save organiztion", null));
        return res.json(Pakage(0, "Save event successfully!", data));
    } catch (error) {
        return res
            .status(400)
            .json(Pakage(2, "Can not save organiztion ", error));
    }
};

export const getOr = async (req, res) => {
    try {
        const data = await organization.find();

        if (!data) {
            return res.json(Pakage(1, "Data is null", null));
        }
        return res.json(Pakage(0, "Get data successfully", data));
    } catch (error) {
        return res.status(400).json(Pakage(2, "Can get data!", error));
    }
};

export const getOrPage = (req, res) => {
    const title = "Organization";
    res.render("organization/index", { title: title });
};

export const delOr = async (req, res) => {
    try {
        const _id = req.params.oid;

        const result = await organization.findByIdAndDelete(_id);
        if (!result) {
            return res.json(Pakage(1, "Can not delete data!", null));
        }
        return res.json(Pakage(0, "Delete data successfully!", result));
    } catch (error) {
        return res.status(400).json(Pakage(2, "Can delete data!", error));
    }
};

export const editOr = async (req, res) => {
    try {
        const _id = req.params.oid;

        const { name, phone, address, email, about } = req.body;
        const dataUpdate = {
            name: name,
            phone: phone,
            about: about,
            address: address,
            email: email,
        };
        const result = await organization.findByIdAndUpdate(_id, dataUpdate, {
            new: true,
        });

        if (!result)
            return res.status(400).json(Pakage(1, "Can not edit data", null));
        return res.json(Pakage(0, "Edit data successfully", result));
    } catch (error) {
        return res.status(400).json(Pakage(2, "Can delete data!", error));
    }
};
