import Survey from "../models/survey.js";
import question from "../models/Question.js";
import Pakage from "../middlewares/pakage.js";

export const getSurveyPage = (req, res) => {
    res.render("survey/index", { title: "Survey" });
};

export const getQuestionPage = (req, res) => {
    res.render("survey/survey", { title: "Question" });
};

export const getUserSurveyPage = (req, res) => {
    res.render("survey/surveyUser", { title: "Survey" });
};

export const postSur = async (req, res) => {
    try {
        const { name, state, startTime, endTime, minResponses, maxResponses } =
            req.body;

        const data = new Survey({
            name: name,
            state: state,
            startTime: startTime,
            endTime: endTime,
            minResponses: minResponses,
            maxResponses: maxResponses,
        });

        const result = await data.save();
        if (!result)
            return res.status(400).json(Pakage(1, "Can not save survey", null));
        return res.json(Pakage(0, "Save survey successfully", data));
    } catch (error) {
        return res.status(400).json(Pakage(1, "Server internal error!"));
    }
};

export const getSur = async (req, res) => {
    try {
        const data = await Survey.find();

        if (!data) return res.json(Pakage(1, "Data is empty", null));
        return res.json(Pakage(0, "Get data successfully", data));
    } catch (error) {
        return res.status(400).json(Pakage(1, "Server internal error!"));
    }
};

export const delSur = async (req, res) => {
    try {
        const _id = req.params.sid;

        const result = await Survey.findByIdAndDelete(_id);
        if (!result) {
            return res.json(Pakage(1, "Can not delete data !", null));
        }
        return res.json(Pakage(0, "Delete data successfully!", result));
    } catch (error) {
        return res.status(400).json(Pakage(1, "Server internal error!"));
    }
};

export const editSur = async (req, res) => {
    try {
        const _id = req.params.sid;

        const { name, state, startTime, endTime, minResponses, maxResponses } =
            req.body;
        const dataUpdate = {
            name: name,
            state: state,
            startTime: startTime,
            endTime: endTime,
            minResponses: minResponses,
            maxResponses: maxResponses,
        };
        const result = await Survey.findByIdAndUpdate(_id, dataUpdate, {
            new: true,
        });

        if (!result)
            return res.status(400).json(Pakage(1, "Can not edit data", null));
        return res.json(Pakage(0, "Edit data successfully", result));
    } catch (error) {
        return res.status(400).json(Pakage(1, "Server internal error!"));
    }
};
