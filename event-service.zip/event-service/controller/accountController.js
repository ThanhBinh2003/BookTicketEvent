import User from "../models/User.js";
import Package from "../middlewares/pakage.js";

//[get] account/
export const index = async (req, res) => {
    try {
        const users = await User.find({ role: "user" });
        const title = "Account";
        res.render("account/index", {
            title: title,
            users: users,
            page: "account",
        });
    } catch (error) {
        console.log(error);
        res.status(500).send("Internal Server Error");
    }
};

export const getAccount = async (req, res) => {
    try {
        const users = await User.find({ role: "user" });
        if (!users) {
            return res.json(Package(1, "Can not get user data", null));
        }
        return res.json(Package(0, "Get user data successfully", users));
    } catch (error) {
        console.log(error);
        return res
            .status(500)
            .json(Package(2, "Internal server error!", error));
    }
};

export const deleteUser = async (req, res) => {
    try {
        const _id = req.params.uid;
        const result = await User.findByIdAndDelete(_id);
        if (!result) {
            return res
                .status(400)
                .json(Package(1, "Can not delete user", null));
        }
        return res.json(Package(0, "Delete user success", result));
    } catch (error) {
        console.log(error);
        res.status(500).json(Package(2, "Can not delete user", null));
    }
};

export const editUser = async (req, res) => {
    try {
        const _id = req.params.uid;
        const { name, email, phone, gender } = req.body;
        const dataUpdate = {
            name,
            email,
            phone,
            gender,
        };
        const result = await User.findByIdAndUpdate(_id, dataUpdate, {
            new: true,
        });
        if (!result) {
            res.json(Package(1, "Update user fail", null));
        }
        res.json(Package(0, "Update use successfully", result));
    } catch (error) {
        res.json(Package(2, "Internal Server Error", null));
    }
};

export const getProfilePage = (req, res) => {
    const title = "Profile";
    res.render("account/profile", { title: title });
};
