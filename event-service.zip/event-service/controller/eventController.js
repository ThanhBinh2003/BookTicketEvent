import eventModel from "../models/Events.js";
import Pakage from "../middlewares/pakage.js";
import { sendMail } from "../utils/mailer.js";
import { sendEmailSmtp } from "../utils/mailerSMTP.js";
//admin
export const postEvent = async (req, res) => {
    try {
        const {
            image,
            eventName,
            address,
            isFree,
            ticketPrice,
            quantity,
            category,
            organization,
            startDate,
            endDate,
            duration,
            users,
            state,
            contentEvent,
        } = req.body;

        const dataEvent = new eventModel({
            picture: image,
            eventName: eventName,
            address: address,
            isFree: isFree,
            ticketPrice: ticketPrice,
            quantity: quantity,
            category: category,
            organization: organization,
            startDate: startDate,
            endDate: endDate,
            duration: duration,
            state: state,
            users: users,
            contentEvent: contentEvent,
        });

        const result = await dataEvent.save();
        if (!result) {
            return res.status(400).json(Pakage(1, "Can not save event", null));
        }
        res.json(Pakage(0, "Save event successfully!", dataEvent));
    } catch (error) {
        return res.status(400).json(Pakage(2, "Can not save event", error));
    }
};

export const getManageEvent = async (req, res) => {
    try {
        const dataEvent = await eventModel.find();

        if (!dataEvent) {
            res.json(Pakage(1, "Get data event fail", null));
        }
        // res.render("events/manageEvent", { title, data: dataEvent });
        res.json(Pakage(0, "Get data successfully", dataEvent));
    } catch (error) {
        res.status(400).json(Pakage(2, "Get data event fail", null));
    }
};

export const getManageEventById = async (req, res) => {
    try {
        const _id = req.params.eid;

        const dataEvent = await eventModel.find({ _id });

        if (!dataEvent) {
            res.json(Pakage(1, "Get data event fail", null));
        }
        res.json(Pakage(0, "Get data successfully", dataEvent));
    } catch (error) {
        res.status(400).json(Pakage(2, "Get data event fail", null));
    }
};

export const getFeeEvent = async (req, res) => {
    try {
        const dataEvent = await eventModel.find({ isFree: false });
        if (!dataEvent) return res.json(Pakage(1, "Can not get data!", null));
        return res.json(Pakage(0, "Get data successfully!", dataEvent));
    } catch (error) {
        res.status(400).json(Pakage(2, "Get data event fail", null));
    }
};

export const renderEventPage = async (req, res) => {
    const title = "Event";

    res.render("events/manageEvent", { title });
};

export const deleteEvetn = async (req, res) => {
    try {
        const _id = req.params.eId;
        const result = await eventModel.findByIdAndDelete(_id);
        if (!result) {
            res.json(Pakage(1, "Can not delete event", null));
        }
        res.json(Pakage(0, "Delete event successfully", result));
    } catch (error) {
        res.status(400).json(Pakage(2, "Can not delete event", null));
    }
};

export const editEvent = async (req, res) => {
    try {
        const _id = req.params.eId;
        const {
            eventName,
            address,
            isFree,
            price,
            quantity,
            category,
            organization,
            startDate,
            endDate,
            duration,
            users,
            contentEvent,
            image,
            state,
        } = req.body;
        const dataUpdate = {
            eventName,
            address: address,
            isFree: isFree,
            ticketPrice: price,
            quantity: quantity,
            category: category,
            organization: organization,
            startDate,
            endDate,
            duration,
            users,
            contentEvent,
            picture: image,
            state: state,
        };

        const result = await eventModel.findByIdAndUpdate(_id, dataUpdate, {
            new: true,
        });

        if (!result) {
            res.json(Pakage(1, "Can not edit event", null));
        }
        res.json(Pakage(0, "Edit event successfully", result));
    } catch (error) {
        console.log(error);
        res.status(400).json(Pakage(2, "Can not edit event", error));
    }
};

export const sendMailEvent = async (req, res) => {
    try {
        const { emails, eventName, content, imageUrl } = req.body;
        let htmlContent = `
            <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd;">
                <h1 style="color: #333; margin-bottom: 20px;">Announcement about ${eventName}</h1>
                <p style="font-size: 16px; color: #666; margin-bottom: 20px;">${content}</p>
                <img src="${imageUrl}" alt="Image Event" style="max-width: 100%; height: auto; display: block; margin-bottom: 20px;">
                <p style="font-size: 14px; color: #888;">This email was sent by ThanhBinh.</p>
            </div> `;
        for (const email of emails) {
            const mailResult = await sendEmailSmtp(
                email,
                `Announcement about ${eventName}`,
                htmlContent
            );
            if (mailResult.status === "error") {
                return res
                    .status(500)
                    .json(Pakage(1, "Can not send email", null));
            } else {
                console.log(mailResult.message);
            }
        }
        res.status(200).json(Pakage(0, "Send email successfully", null));
    } catch (error) {
        res.status(500).json(Pakage(2, "Can not send mail", error.message));
    }
};

export const listEvent = (req, res) => {
    const title = "List events";
    res.render("events/event", { title: title });
};

export const listUserRegister = (req, res) => {
    const title = "List user";
    res.render("events/detailEventRegistrants", { title: title });
};

export const listUserEvent = (req, res) => {
    const title = "List event";
    res.render("events/eventOfUser", { title: title });
};

export const detailEvent = async (req, res) => {
    const title = "Detail event";
    res.render("events/detailEvent", { title: title });
};

//get feeEvent page
export const getFeeEventPage = (req, res) => {
    const title = "Fee event";
    res.render("events/feeEvent", { title: title });
};

export const getFeeEventUserPage = (req, res) => {
    const title = "Event";
    res.render("events/paidEvent", { title: title });
};

export const getDetailPaidEvent = (req, res) => {
    const title = "Detail event";
    res.render("events/detailPaidEvent", { title: title });
};

export const getSuccessPage = (req, res) => {
    res.render("order/success", { title: "Success" });
};
export const getCancelPage = (req, res) => {
    res.render("order/cancel", { title: "Cancel" });
};
