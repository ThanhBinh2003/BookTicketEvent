import Order from "../models/Order.js";
import Event from "../models/Events.js";
import moment from "moment";
import ObjectId from "mongodb";
import Pakage from "../middlewares/pakage.js";
import config from "config";
import querystring from "qs";
import crypto from "crypto";
import paypal from "paypal-rest-sdk";
import { sendEmailSmtp } from "../utils/mailerSMTP.js";

export const storeOrder = (req, res) => {};

export const getOrderPage = (req, res) => {
    const title = "Order";
    res.render("order/payment", { title: title });
};

export const getBooking = (req, res) => {
    const title = "Booking";
    res.render("order/booking", { title: title });
};

export const store = async (req, res, next) => {
    try {
        const { items, isPay } = req.body;
        let totalPice = items.ticketPrice * items.quantity;

        let event = {
            eventId: items._id,
            quantity: items.quantity,
        };

        const order = new Order({
            userId: req.user.username,
            items: event,
            isPay: isPay,
            totalPice: totalPice,
            createdAt: moment().format("MM/DD/YYYY, hh:mm:ss"),
            timestamp: moment().unix(),
        });

        const eventInDB = await Event.findById(event.eventId);
        if (eventInDB.quantity < event.quantity) {
            throw new Error("Not enough ticket in stock");
        }
        eventInDB.quantity -= event.quantity;
        await eventInDB.save();

        const newOrder = await order.save();
        return res
            .status(200)
            .json(Pakage(0, "Store order successfully!", newOrder));
    } catch (error) {
        return res
            .status(400)
            .json(Pakage(2, "Can not store order", error.message));
    }
};

export const VNPay = (req, res, next) => {
    process.env.TZ = "Asia/Ho_Chi_Minh";

    let date = new Date();
    let createDate = moment(date).format("YYYYMMDDHHmmss");

    let ipAddr =
        req.headers["x-forwarded-for"] ||
        req.connection.remoteAddress ||
        req.socket.remoteAddress ||
        req.connection.socket.remoteAddress;

    let tmnCode = config.get("vnp_TmnCode");
    let secretKey = config.get("vnp_HashSecret");
    let vnpUrl = config.get("vnp_Url");
    let returnUrl = config.get("vnp_ReturnUrl");
    // let orderId = moment(date).format("DDHHmmss");
    let amount = req.body.amount;
    let bankCode = req.body.bankCode;

    let locale = req.body.language;
    if (locale === null || locale === "") {
        locale = "vn";
    }
    let currCode = "VND";
    let vnp_Params = {};
    vnp_Params["vnp_Version"] = "2.1.0";
    vnp_Params["vnp_Command"] = "pay";
    vnp_Params["vnp_TmnCode"] = tmnCode;
    vnp_Params["vnp_Locale"] = locale;
    vnp_Params["vnp_CurrCode"] = currCode;
    vnp_Params["vnp_TxnRef"] = req.body.orderId;
    vnp_Params["vnp_OrderInfo"] = "Thanh toan cho ma GD:" + req.body.orderId;
    vnp_Params["vnp_OrderType"] = "other";
    vnp_Params["vnp_Amount"] = amount * 100;
    vnp_Params["vnp_ReturnUrl"] = returnUrl;
    vnp_Params["vnp_IpAddr"] = ipAddr;
    vnp_Params["vnp_CreateDate"] = createDate;
    if (bankCode !== null && bankCode !== "") {
        vnp_Params["vnp_BankCode"] = bankCode;
    }

    vnp_Params = sortObject(vnp_Params);

    let signData = querystring.stringify(vnp_Params, { encode: false });
    let hmac = crypto.createHmac("sha512", secretKey);
    let signed = hmac.update(new Buffer(signData, "utf-8")).digest("hex");
    vnp_Params["vnp_SecureHash"] = signed;
    vnpUrl += "?" + querystring.stringify(vnp_Params, { encode: false });

    res.json({ url: vnpUrl });
};

export const VNPayReturn = async (req, res, next) => {
    let vnp_Params = req.query;

    let secureHash = vnp_Params["vnp_SecureHash"];

    delete vnp_Params["vnp_SecureHash"];
    delete vnp_Params["vnp_SecureHashType"];

    vnp_Params = sortObject(vnp_Params);

    let tmnCode = config.get("vnp_TmnCode");
    let secretKey = config.get("vnp_HashSecret");

    let signData = querystring.stringify(vnp_Params, { encode: false });
    let hmac = crypto.createHmac("sha512", secretKey);
    let signed = hmac.update(new Buffer(signData, "utf-8")).digest("hex");

    if (secureHash === signed) {
        let code = vnp_Params["vnp_ResponseCode"];
        if (code === "00") {
            const _id = vnp_Params["vnp_TxnRef"];
            const isPay = await Order.findByIdAndUpdate(
                _id,
                { isPay: true, paymentMethod: "VnPay" },
                { new: true }
            );
            await sendMail(_id, req.user.name, req.user.email, req.user._id);
            res.render("order/success", {
                title: "Success",
            });
        } else {
            res.render("order/fail", { code: "97" });
        }
    } else {
        res.render("order/fail", { code: "97" });
    }
};

function sortObject(obj) {
    let sorted = {};
    let str = [];
    let key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            str.push(encodeURIComponent(key));
        }
    }
    str.sort();
    for (key = 0; key < str.length; key++) {
        sorted[str[key]] = encodeURIComponent(obj[str[key]]).replace(
            /%20/g,
            "+"
        );
    }
    return sorted;
}

async function sendMail(orderId, username, userEmail, userId) {
    try {
        const order = await Order.findById(orderId);
        const event = await Event.findById(order.items.eventId);

        const dataUpdate = {
            userId: userId,
            email: userEmail,
            registerTime: moment().format("MM/DD/YYYY, hh:mm:ss"),
        };

        await Event.findByIdAndUpdate(event._id, dataUpdate, { new: true });

        let contentHtml = `<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 20px;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #fff;
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                }
                h2 {
                    color: #333;
                }
                p {
                    color: #666;
                }
                .event-info {
                    margin-top: 20px;
                }
                .event-info table {
                    width: 100%;
                    border-collapse: collapse;
                }
                .event-info th,
                .event-info td {
                    padding: 10px;
                    border-bottom: 1px solid #ccc;
                    text-align: left;
                }
                .event-info th {
                    background-color: #f4f4f4;
                }
                .payment-info {
                    margin-top: 20px;
                    border-top: 1px solid #ccc;
                    padding-top: 20px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Event Ticket Booking Confirmation</h2>
                <p>Hi <span style="font-weight: bold;">${username},</span></p>
                <p>Thank you for booking tickets for our event <span style="font-weight: bold;">${event.eventName}</span>. Here are the details of your booking:</p>
        
                <div class="event-info">
                    <table>
                        <tr>
                            <th>Event Name</th>
                            <td>${event.eventName}</td>
                        </tr>
                        <tr>
                            <th>Date</th>
                            <td>${event.startDate}</td>
                        </tr>
                        <tr>
                            <th>Time</th>
                            <td>${event.duration.startTime}</td>
                        </tr>
                        <tr>
                        <th>Quantity</th>
                            <td>${order.items.quantity}</td>
                        </tr>
                    </table>
                </div>
        
                <div class="payment-info">
                    <p><span style="font-weight: bold;">Payment Information:</span></p>
                    <p>Total Amount(VNĐ): <span style="font-weight: bold;">${order.totalPice}</span></p>
                    <p>Payment Method: <span style="font-weight: bold;">${order.paymentMethod}</span></p>
                </div>
        
                <p>We look forward to welcoming you to the event. If you have any questions, please feel free to contact us.</p>
                <p>Best regards,<br>Mai Thanh Binh</p>
            </div>
        </body>
        </html>
        `;
        console.log("hi");
        const mailResult = await sendEmailSmtp(
            userEmail,
            `Event ticket booking information - OrderId: ${orderId}`,
            contentHtml
        );
    } catch (error) {
        console.log(error);
    }
}

export const getStatisticsPage = (req, res) => {
    res.render("order/statistics", { title: "Statistics" });
};

export const getOrder = async (req, res) => {
    try {
        const data = await Order.find();
        if (!data) return res.json(Pakage(2, "Can not get data", null));
        return res.json(Pakage(0, "Get data successfully!", data));
    } catch (error) {
        return res.json(Pakage(1, "Can not get data", error.message));
    }
};

export const payZalo = async (req, res, next) => {
    paypal.configure({
        mode: "sandbox", //sandbox or live
        client_id:
            "AZByfgfgb7Jtq45FzPMM2wmCtoChqDfBwMr0kwYT4IzJqTn_TzDjspnJocos7XSZF93sjRR9sePF73bO",
        client_secret:
            "ELaZaNkfTJiLMCzNNS9Imya2sa1PXjK7QcZmv86GwqHi88J0GN2xmJXzuaZTNgrCwOa2F0QWnDBHhzZE",
    });

    var create_payment_json = {
        intent: "sale",
        payer: {
            payment_method: "paypal",
        },
        redirect_urls: {
            return_url: "http://localhost:3000/success",
            cancel_url: "http://localhost:3000/cancel",
        },
        transactions: [
            {
                item_list: {
                    items: [
                        {
                            name: req.body.name,
                            sku: "item",
                            price: req.body.amount / req.body.quantity,
                            currency: "USD",
                            quantity: 1,
                        },
                    ],
                },
                amount: {
                    currency: "USD",
                    total: req.body.amount,
                },
                description: "This is the payment description.",
            },
        ],
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            throw error;
        } else {
            for (let i = 0; i < payment.links.length; i++) {
                if (payment.links[i].rel === "approval_url") {
                    res.json({ url: payment.links[i].href });
                }
            }
        }
    });
};
