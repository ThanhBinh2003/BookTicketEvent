import bcrypt from "bcrypt";
import User from "../models/User.js";
import Pakage from "../middlewares/pakage.js";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import jwt from "jsonwebtoken";
import moment from "moment";

export const postRegister = async (req, res) => {
    try {
        const { name, email, password, role, phone, gender } = req.body;
        const username = email.split("@")[0];
        const existedUser = await User.findOne({ email });
        if (existedUser) {
            return res.status(300).json(Pakage(1, "Email is existed", null));
        } else {
            const hashedPassword = await bcrypt.hash(password, 10);

            const newUser = new User({
                username: username,
                name: name,
                email: email,
                password: hashedPassword,
                role: role,
                phone: phone,
                gender: gender,
                createdAt: moment().format("MM/DD/YYYY, hh:mm:ss"),
            });
            const savedUser = await newUser.save();
            res.status(200).json(
                Pakage(0, "Create user successfully", savedUser)
            );
        }
    } catch (err) {
        console.log(err);
        return res.status(500).json(Pakage(1, "Fail to create user", null));
    }
};

export const getRegiter = (req, res) => {
    const title = "Register";
    res.render("auth/register", { title: title, page: "auth/register" });
};

export const getLogin = (req, res) => {
    const title = "Login";
    res.render("auth/login", { title: title, page: "auth/login" });
};

//cau hinh Passport LocalStrategy
passport.use(
    new LocalStrategy(
        { usernameField: "username" },
        async (username, password, done) => {
            try {
                // tìm user trong db theo username
                const user = await User.findOne({ username });

                //check user exist
                if (!user) {
                    return done(null, false, {
                        message: "Username or password incorrect",
                    });
                }

                //compare password
                bcrypt.compare(password, user.password, (err, result) => {
                    if (result) {
                        //mat khau khop tao token
                        const token = jwt.sign(
                            { _id: user._id, data: user },
                            "SOA-FINAL",
                            { expiresIn: "24h" }
                        );
                        return done(null, user, { token });
                    } else {
                        //wrong password
                        return done(null, false, {
                            message: "Incorrect username or password",
                        });
                    }
                });
            } catch (err) {
                return done(err);
            }
        }
    )
);

// Cấu hình Passport se và dese
passport.serializeUser((user, done) => {
    done(null, user._id);
});

passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id);
        done(null, user);
    } catch (error) {
        done(error);
    }
});

// dang nhap
export const postLogin = (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
        res.clearCookie("token");
        if (err) {
            return next(err);
        }
        if (!user) {
            return res.status(400).json(Pakage(1, info.message, null));
        }

        req.logIn(user, (err) => {
            if (err) {
                return next(err);
            }
            res.cookie("token", info.token, { maxAge: 24 * 60 * 60 * 1000 });
            const data = user;

            data.password == undefined;
            return res.status(200).json(Pakage(0, "Login successfully", data));
        });
    })(req, res, next);
};

export const logout = (req, res, next) => {
    if (req.logout) {
        req.logout(function (err) {
            if (err) {
                return next(err);
            }
            res.clearCookie("token");
            res.redirect("/auth/login");
        });
    } else {
        res.clearCookie("token");
        res.redirect("/auth/login");
    }
};

export const changePassword = async (req, res) => {
    try {
        const { uid, oldPassword, newPassword } = req.body;
        const user = await User.findOne({ _id: uid });

        if (!user) {
            return res.json(Package(1, "Can not get user", null));
        }

        bcrypt.compare(oldPassword, user.password, async (err, result) => {
            if (result) {
                const hashedPassword = bcrypt.hash(newPassword, 10);
                const dataUpdate = { password: hashedPassword };
                const result = await User.findByIdAndUpdate({
                    _id: uid,
                    dataUpdate,
                    new: true,
                });

                if (user) {
                    return res.json(
                        Pakage(0, "Change password successfully!", null)
                    );
                } else
                    return res.json(Pakage(2, "Can not change password", null));
            } else {
                return res.json(Pakage(1, "Can not change password", null));
            }
        });
    } catch (error) {
        res.json(Package(2, "Can not change password", null));
    }
};
